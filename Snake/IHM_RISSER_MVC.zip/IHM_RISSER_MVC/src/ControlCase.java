import View.HoverButton;
import View.Win;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by rydkey on 22/05/16.
 */
public class ControlCase implements ActionListener {
    Fenetre fenetre;
    Win victory;
    Model model;
    String time;
    int position;
    boolean move;

    public ControlCase(Fenetre fenetre, Model model){
        this.fenetre=fenetre;
        this.model=model;
        fenetre.setControlCase(this);
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        HoverButton boutonclick= (HoverButton) actionEvent.getSource();
        String str = String.valueOf(boutonclick.getText()); /* Text dans le bouton */

        if (str==""){
            str=String.valueOf(16);
        }
        position = model.getPosition(Integer.parseInt(str));
        move=model.Move(position);

        if (move==true && model.game==true){
            fenetre.but[model.CaseVide].setText(str);
            fenetre.but[model.position].setText("");
            model.changeGameBoard(position);
            model.win=model.testWin();
        }
        if(model.win==true){
            if (model.win==true){
                for(int i=0;i<fenetre.but.length;i++) {
                    fenetre.but[i].setText("");
                    model.GameBoard[1][i]=0;
                }
            }
            model.Win();
            time=model.getTime();
            victory = new Win(time);
        }
    }
}
