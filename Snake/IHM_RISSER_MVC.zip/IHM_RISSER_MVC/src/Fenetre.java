import View.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Created by rydkey on 5/21/16.
 */
public class Fenetre extends JFrame {

    public Model model;
    public JPanel all;
    public JPanel dispHoverButton;
    public JPanel dispButTime;
    public JLabel Timer;
    public HoverButton[] but;
    public JButton startTime,stopTime;

    JMenuBar barMenu;
    JMenu menu;
    JMenuItem item2;


    ControlButtonStart cB;
    ControlMenu cM;

    public Fenetre(Model model) {
        this.model=model;

        /*
        * Définition de la fenêtre.
        * */

        setPanel();

        /*
        *Définition de la barre de menu
         */

        setMenuBar();

        /*
        Définition Bouton
         */

        setButton();

        all.add(dispHoverButton,BorderLayout.CENTER);
        all.add(dispButTime,BorderLayout.SOUTH);
        add(all);

        setTitle("Puzzle");
        setMinimumSize(new Dimension(this.model.sizeWindow, this.model.sizeWindow));
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void setPanel() {
        dispHoverButton = new JPanel(new GridLayout(model.sizeGridX, model.sizeYGrid));
        dispButTime = new JPanel();
        all = new JPanel(new BorderLayout());
    }

    private void setMenuBar() {
        barMenu = new JMenuBar();
        menu = new JMenu("Options");
        item2 = new JMenuItem("Score");

        menu.add(item2);
        barMenu.add(menu);
        setJMenuBar(barMenu);
    }

    private void setButton() {
        but = new HoverButton[model.Case];
        for(int i = 0; i< model.Case; i++){
            but[i]=new HoverButton();
            dispHoverButton.add(but[i]);
        }
        startTime = new JButton("Start");
        stopTime = new JButton("Stop");
        Timer = new JLabel(""+ model.time[2]+":"+model.time[1]+":"+ model.time[0]);
        Timer.setPreferredSize(new Dimension(60,25));
        dispButTime.add(startTime);
        dispButTime.add(stopTime);
        dispButTime.add(Timer);
    }

    public void setControlButtonStart(ActionListener all) {
        startTime.addActionListener(all);
    }

    public void setControlButtonStop(ActionListener all) {
        stopTime.addActionListener(all);
    }

    public void setControlMenu(ActionListener all){
        item2.addActionListener(all);
    }

    public void setControlCase(ActionListener all) {
        for (int i=0;i<but.length;i++){
            but[i].addActionListener(all);
        }
    }
}