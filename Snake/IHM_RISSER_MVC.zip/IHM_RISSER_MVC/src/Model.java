
import View.Win;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by rydkey on 22/05/16.
 */
class Model {
    public int sizeGridX, sizeYGrid, sizeWindow,delai,Case,CaseVide,position,tmp,tmp1;
    public int[] time= new int[3];
    public boolean win,game;
    public String tabScore="";
    public String finalTime;
    public FileInputStream fis;
    public Timer timer1;
    public ArrayList gridList;
    public int[][] GameBoard = new int[2][16];
    Model() {
        Case = 16;
        sizeWindow=800;
        sizeGridX =4;
        sizeYGrid =4;
        delai=1;
        time[0]=0;
        time[1]=0;
        time[2]=0;
        win=false;
        game=false;
    }

    /*
    Set
     */

    void setCaseVide(int i){
        CaseVide=i;
    }

    int[][] setGrid(int nbrList){
        gridList= new ArrayList();
        for(int i=0;i<16;i++) {
            GameBoard[0][i]=i+1;
            GameBoard[1][i]=i;
            gridList.add(i+1);
        }
        Collections.shuffle(gridList);
        for(int i=0;i<16;i++){
            GameBoard[1][i]=Integer.parseInt(gridList.get(i).toString());
        }
        return GameBoard;
    }

    void delTabScore(){
        tabScore="";
    }

    void reinitTime(){
        for(int i=0; i< time.length;i++){
            time[i]=0;
        }
    }

    void setGame(boolean b){
        game = b;
    }

    public void changeGameBoard(int position) {
        tmp1=CaseVide;
        CaseVide= position;
        position=tmp1;
        tmp = GameBoard[1][position];
        GameBoard[1][position]= GameBoard[1][CaseVide];
        GameBoard[1][CaseVide]= tmp;
    }

    /*
    end Set
     */

    /*
    get
    */
    ArrayList getList (){
        return gridList;
    }

    String getScore(){
        try {
            fis= new FileInputStream(new File("txt/score.txt"));
            // On crée un tableau de byte pour indiquer le nombre de bytes lus à
            // chaque tour de boucle
            byte[] buf = new byte[8];

            // On crée une variable de type int pour y affecter le résultat de
            // la lecture
            // Vaut -1 quand c'est fini
            int n = 0;

            // Tant que l'affectation dans la variable est possible, on boucle
            // Lorsque la lecture du fichier est terminée l'affectation n'est
            // plus possible !
            // On sort donc de la boucle
            while ((n = fis.read(buf)) >= 0) {
                // On stock ce qu'a lu notre boucle au format byte une fois convertit
                // Au format char dans la chaine de caractère tabScore
                for (byte bit : buf) {
                    if ((char) bit == (char) bit  ){
                        tabScore = tabScore +(char) bit;
                    }
                }
                buf = new byte[8];
                //réinitialisation buffer à vide
                //au cas où les derniers byte lus ne soient pas un multiple de 8
                //Ceci permet d'avoir un buffer vierge à chaque lecture et ne pas avoir de doublon en fin de fichier

            }
        } catch (FileNotFoundException e) {
            // Cette exception est levée si l'objet FileInputStream ne trouve
            // aucun fichier
            e.printStackTrace();
            tabScore = "Erreur de lecture";
        } catch (IOException e) {
            // Celle-ci se produit lors d'une erreur d'écriture ou de lecture
            e.printStackTrace();
            tabScore = "Erreur de lecture";
        } finally {
            // On ferme notre flux de donnée dans un bloc finally pour s'assurer
            // que ces instructions seront exécutées dans tous les cas même si
            // une exception est levée !
            try {
                if (fis != null)
                    fis.close();
            } catch (IOException e) {
                e.printStackTrace();
                tabScore = "Erreur de lecture";
            }
        }
        return tabScore;
    }

    String getTime(){
        finalTime = String.valueOf(time[2]+":"+time[1]+":"+time[0]);
        return finalTime;
    }

    public int getPosition(int test) {
        for (int i=0;i<Case;i++){
            if (GameBoard[1][i]==test){
                position = i;
            }
        }
        return position;
    }

    /*
    endGet
     */

    void startGame(){
        reinitTime();
        setGame(true);
        timer1.start();
    }

    void stopGame(){
        setGame(false);
        timer1.stop();
    }

    public boolean Move(int position) {
        if (position==CaseVide+1 || position==CaseVide-1 || position==CaseVide+4 || position==CaseVide-4){
            return true;
        } else{
            return false;
        }
    }

    public boolean testWin() {
        for(int i=0;i<16;i++) {
            if (GameBoard[0][i] != GameBoard[1][i]) {
                return false;
            }
        }
        game=false;
        return true;
    }

    public void Win() {
        stopGame();
        timer1.stop();
        win=true;
    }
}

