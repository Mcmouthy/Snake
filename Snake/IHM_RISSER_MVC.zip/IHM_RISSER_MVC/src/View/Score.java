package View;
import javax.swing.*;

/**
 * Created by rydkey on 11/04/16.
 */
public class Score extends JFrame{

    public Score(String thisLine){
        JOptionPane d = new JOptionPane();
        d.showMessageDialog( this, thisLine, "Score",
                JOptionPane.PLAIN_MESSAGE );
    }

}
