package View;

import javax.swing.*;
import java.awt.event.WindowListener;

/**
 * Created by rydkey on 12/04/16.
 */
public class Win extends JFrame {

    public Win(String time){
        JOptionPane d = new JOptionPane();
        String thisLine="Félicitation ! \n vous avez terminé ce puzzle en "+time+" !";
        d.showMessageDialog(this,thisLine,"Victoire",JOptionPane.PLAIN_MESSAGE );
    }
}
