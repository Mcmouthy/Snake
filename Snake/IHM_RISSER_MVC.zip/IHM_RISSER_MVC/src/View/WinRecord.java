package View;

import javax.swing.*;

/**
 * Created by rydkey on 12/04/16.
 */
public class WinRecord extends JFrame {

    public WinRecord(){
        JOptionPane d = new JOptionPane();
        String thisLine="Félicitation ! \n vous avez fait un nouveau record, entrez votre pseudo (5 caractères) :";
        String pseudo= d.showInputDialog(this,thisLine,"Victoire",JOptionPane.INFORMATION_MESSAGE);
    }
}
