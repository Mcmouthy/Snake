package View; /**
 * Created by rydkey on 13/04/16.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class HoverButton extends JButton {

    private Font font = new Font("Courier",Font.BOLD,20);
    public int rang;

    public HoverButton() {
        setFocusPainted(false);
        setPreferredSize(new Dimension(200,200));
        setBackground(Color.GRAY);
        setBorder(null);
        setFont(font);
        addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent mouseEvent) {
            }

            @Override
            public void mousePressed(MouseEvent mouseEvent) {
            }

            @Override
            public void mouseReleased(MouseEvent mouseEvent) {
            }

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {
                setBackground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent mouseEvent) {
                setBackground(Color.GRAY);
            }
        });
    }
}