import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by rydkey on 22/05/16.
 */
public class ControlButtonStop implements ActionListener {
    Fenetre fenetre;
    Model model;

    public ControlButtonStop(Fenetre fenetre, Model model) {
        this.fenetre = fenetre;
        this.model = model;
        fenetre.setControlButtonStop(this);
    }

    public void actionPerformed(ActionEvent e) {
        model.stopGame();
        fenetre.Timer.setText(""+model.time[2]+":"+model.time[1]+":"+model.time[0]);
        for(int i=0;i<fenetre.but.length;i++){
            fenetre.but[i].setText("");
        }
    }
}
