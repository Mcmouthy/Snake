/**
 * Created by rydkey on 5/21/16.
 */
public class ControlGroup {

    public ControlGroup(Model Model){
        Fenetre fenetre= new Fenetre(Model);
        ControlButtonStart controlButtonStart = new ControlButtonStart(fenetre, Model);
        ControlButtonStop controlButtonStop = new ControlButtonStop(fenetre, Model);
        ControlCase controlCaseVide = new ControlCase(fenetre,Model);
        ControlMenu cM = new ControlMenu(fenetre, Model);
        fenetre.setVisible(true);
    }
}
