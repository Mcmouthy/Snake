import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import View.Score;

/**
 * Created by rydkey on 5/21/16.
 */
public class ControlMenu implements ActionListener {

    Fenetre fenetre;
    Model model;
    Score score;
    String thisLine;

    public ControlMenu(Fenetre fenetre, Model model){
        this.fenetre=fenetre;
        this.model=model;
        fenetre.setControlMenu(this);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        thisLine = model.getScore();
        score= new Score(thisLine);
        model.delTabScore();
    }
}
