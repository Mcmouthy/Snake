/**
 * Created by rydkey on 5/21/16.
 */
public class Puzzle {


    public static void main (String[] args){

        javax.swing.SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                Model model = new Model();
                ControlGroup control = new ControlGroup(model);
            }
        });
    }
}
