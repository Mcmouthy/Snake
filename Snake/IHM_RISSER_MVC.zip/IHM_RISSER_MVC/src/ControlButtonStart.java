import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by rydkey on 5/21/16.
 */
public class ControlButtonStart implements ActionListener{
    Fenetre fenetre;
    Model model;
    public ControlButtonStart(Fenetre fenetre, Model model){
        this.fenetre=fenetre;
        this.model =model;
        fenetre.setControlButtonStart(this);
    }

    public void actionPerformed(ActionEvent e){
        if (model.game==false){
            model.setGame(true);
            int[][] tableauCase;
            ActionListener tache_timer= new ActionListener()
            {
                public void actionPerformed(ActionEvent e1)
                {
                    model.time[0]++;
                    if(model.time[0]==1000)
                    {
                        model.time[0]=0;
                        model.time[1]++;
                    }
                    if(model.time[1]==60)
                    {
                        model.time[1]=0;
                        model.time[2]++;
                    }
                    fenetre.Timer.setText(""+model.time[2]+":"+model.time[1]+":"+model.time[0]);/* rafraichir le label */
                }
            };
        /* instanciation du timer */
            model.timer1= new Timer(model.delai,tache_timer);
            model.startGame();
            tableauCase=model.setGrid(model.Case);

            for(int i=0;i<fenetre.but.length;i++){
                if (tableauCase[1][i]==16){
                    fenetre.but[i].setText("");
                    model.setCaseVide(i);
                }else{
                    fenetre.but[i].setText(String.valueOf(tableauCase[1][i]));
                }
            }
        }

		/* Ajout des composants aux conteneurs avec formatage */
		/* Action provoqué par l'utilisateur */
		/* Lors du clic sur le bouton debut */
    }
}